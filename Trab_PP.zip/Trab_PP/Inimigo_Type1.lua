
slime = {}
slime.__index = slime

Inimigo_11 = love.graphics.newImage( "Sprite//Inimigo_1.png" )
Inimigo_22 = love.graphics.newImage( "Sprite//Inimigo_2.png" )
Inimigo_33 = love.graphics.newImage( "Sprite//Inimigo_3.png" )
Inimigo_44 = love.graphics.newImage( "Sprite//Inimigo_4.png" )

function Create(x1,x2,x3,x4,world,id)

    local this = {}
    x = math.random(x1, x1+x3)
    y = math.random(x2, x2+x4)

    tipo_inimigo  = math.random(1, 100)

    if tipo_inimigo > 40 and tipo_inimigo <= 75 then

        this.image = Inimigo_11
        this.dano = 3
        this.Velocidade = 150

    elseif tipo_inimigo <= 40  then

        this.image = Inimigo_22
        this.dano = 1
        this.Velocidade = 200

    elseif tipo_inimigo > 75 and tipo_inimigo < 95 then

        this.image = Inimigo_33
        this.dano = 5
        this.Velocidade = 130

    elseif tipo_inimigo >= 95 then

        this.image = Inimigo_44
        this.dano = 10
        this.Velocidade = 100

    end

    this.colider = world:newCircleCollider(x,y,6)
    this.colider:setCollisionClass('Inimigo')
    this.colider:setType('dynamic')

    this.vida = 10
    this.resistencia = 1
    this.id = id
    this.x = 0
    this.y = 0
    this.andar = 0
    this.percp = 100
    this.pers = false

    
    setmetatable(this, slime)
    return this
end


function slime:load()
 
end

function slime:update()
    if self.vida > 0 then
        
        self:vision()

        if self.pers then
            self:perseguindo()
        else
            self:mov()
        end
        self:int()
    end
end

function slime:draw()
    local px, py = self.colider:getPosition()
    love.graphics.draw( self.image, px-6,py-6,0,2,2)
end

function slime:getPos()
    local px, py = self.colider:getPosition()
    return px, py
end


function slime:mov()

    
    if self.andar > 0 then

        XMAX, YMAX = getAreaMap(cenario)
        self.andar = self.andar - 1
        local px, py = self.colider:getPosition()
        

        if px - 10 <= 0 then
            self.x = 1
        elseif px + 10 >= XMAX then
            self.x = -1
        end

        if py + 10 >= YMAX then
            self.y = -1
        elseif py - 10 <= 0 then
            self.y = 1
        end

        self.colider:setLinearVelocity(self.x/self.Velocidade, self.y/self.Velocidade)
    else

        local vectorX = math.random(-1, 1)
        local vectorY = math.random(-1, 1)
        self.x = vectorX
        self.y = vectorY
        self.andar = 200

    end



end


function slime:perseguindo()

    local px, py = getPosJogador()
    local x, y = self.colider:getPosition()

        if px > x then
            self.x = 1
        else
            self.x = -1
        end

        if py > y then
            self.y = 1
        else
            self.y = -1
        end

        self.colider:setLinearVelocity(self.x/self.Velocidade, self.y/self.Velocidade)

end

function slime:vision()

    local px, py = getPosJogador()
    local x, y = self.colider:getPosition()
    
    if x + self.percp > px then
        if x - self.percp < px then
            if y + self.percp > py then
                if y - self.percp < py then
                    self.pers = true
                else
                    self.pers = false
                end
            else
                self.pers = false
            end
        else
            self.pers = false
        end
    else
        self.pers = false
    end
        
end

function slime:int()

    if self.colider:enter('Player') then
        getDamage(self.dano, "fisico")
    end

    if self.colider:enter('Ataque_Player') then
        Jogador.Pontuacao = Jogador.Pontuacao + self.dano
        inimigoMorto(self.id)
        self.colider:destroy()
    end

end

