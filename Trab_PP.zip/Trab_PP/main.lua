STI = require("Modulos//sti")
controler = require "game_controller"



function love.load()
    controler:load()
end

function love.update()
    controler:update()
end

function love.draw()
    controler:draw()
end