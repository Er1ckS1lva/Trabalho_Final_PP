
command = require "command"
STI = require("Modulos//sti")
local CM = require "Modulos//CameraMgr".newManager()

local game_controller = {}

rodando = true
Escala = 2
XMAX = 0
YMAX = 0

mapa1 = "Mapas//Mapa_1.lua" 
--mapa1 = "Mapas//Vitoria.lua"

function game_controller:load()

    if rodando then
        jogo_init(mapa1)
    end

end


function game_controller:update()

    if rodando then
        command:update()
        cenario:update()
        Jx, Jy = getPosJogador()
        CM.setTarget(Jx+16/2, Jy+32/2)
        CM.update()
     end

end

function game_controller:draw()

    if rodando then
        CM.attach()
          Jx, Jy = getPosJogador()
          local screen_width  = love.graphics.getWidth()  / Escala
          local screen_height = love.graphics.getHeight() / Escala
          local tx = math.floor(Jx - screen_width  / 2)
          local ty = math.floor(Jy - screen_height / 2)
          cenario:draw(-tx, -ty, Escala)
          command:draw()
    
        CM.detach()
        CM.debug()
      end

end

function jogo_init(cenario__)

    cenario_atual = cenario__
    cenario = carregando_Mapa(cenario_atual)
    XMAX, YMAX = getAreaMap(cenario)
  
    colisor_init(cenario, false)
  
    CM.setScale(Escala)
    Jx, Jy = cenario.layers.Personagem.objects[1].x, cenario.layers.Personagem.objects[1].y
    CM.setCoords(Jx, Jy)
  
end

function carregando_Mapa(caminho_mapa)
    mapa_atual = STI(caminho_mapa,{"box2d"})
    love.physics.setMeter(32)
    world = love.physics.newWorld(0, 0)
    mapa_atual:box2d_init(world)
    return mapa_atual
end
  
function getAreaMap(cenario)
    XMAX = cenario.width * cenario.tilewidth
    YMAX = cenario.height * cenario.tileheight
    return XMAX,YMAX
end


return game_controller