local CM = require "Modulos//CameraMgr".newManager()
local tirinho = require "Tirinho"

Jogador = {}

mapa2 = "Mapas//Mapa_2.lua"
vitoria = "Mapas//Vitoria.lua"

Jogador.VidaAtual = 50
Jogador.VidaMax = 50

Jogador.JogadorX = 16 
Jogador.JogadorY = 16 
Jogador.JogadorAltura = 8
Jogador.JogadorLargura = 8
Jogador.Velocidade = 20

Jogador.Dano = 3 
Jogador.Defesa = 1
Jogador.Collider = nil
Jogador.AtaqueCD = 0
Jogador.dirr = ''
Jogador.Pontuacao = 0
Jogador.Cura = 2
cura_cool = 1000

colisor_mapa = nil

tiros = {
    id = nil,
    tiro = nil

}
tiros_pos = 0

Jogador_img = love.graphics.newImage( "Sprite//Jogador.png" )

function Jogador:load(mapa)
    
end

function Jogador:update(dt)


    if Jogador.Collider:enter('Inimigo') then
        print('DAMAGEEEEEEEEE !!!!!!!')
    end

    Jogador_movimentacao()
    ataque()
    cura()
    if Jogador.AtaqueCD > 0 then
        Jogador.AtaqueCD = Jogador.AtaqueCD - 1
    end
    
    
    for j in ipairs(tiros) do
        tiros[j].tiro:update()
        
    end
    

end

function Jogador:draw()

    for j in ipairs(tiros) do
        tiros[j].tiro:draw()
    end

    local px, py = Jogador.Collider:getPosition()
    love.graphics.draw( Jogador_img, px-8,py-8,0,1,1)
    love.graphics.print("Vida: "..Jogador.VidaAtual,px-12, py-20,0,0.5,0.5)
    love.graphics.print("Pontuação: "..Jogador.Pontuacao,px-12, py-30,0,0.5,0.5)
    love.graphics.print("Cura: "..Jogador.Cura,px-12, py-40,0,0.5,0.5)

    if cenario_atual == vitoria then

        love.graphics.print("VITORIAAAAAA",px-50, py-80,0,2,2)

    end

end

function Jogador_movimentacao()

    local vectorX = 0
    local vectorY = 0

    if Jogador.Collider:enter('Mapa_Novo') then
        colisor_mapa = Jogador.Collider:getEnterCollisionData('Mapa_Novo')
        local name = nil
        
        if cenario_atual == mapa1 then

            cenario_atual = mapa2
            Jx = 728
            Jy = 306.667
            
            cenario = carregando_Mapa(cenario_atual)
            XMAX, YMAX = getAreaMap(cenario)
        
            CM.setScale(1.5)
            CM.setCoords(Jx, Jy)
            setPosJogador(Jx, Jy)
            reset_Data()
            colisor_init(cenario, true)

        else

            cenario_atual = vitoria
            Jx = 97.5
            Jy = 117.5
            
            cenario = carregando_Mapa(cenario_atual)
            XMAX, YMAX = getAreaMap(cenario)
        
            CM.setScale(1.5)
            CM.setCoords(Jx, Jy)
            setPosJogador(Jx, Jy)
            colisor_init(cenario, true)

        end
    end

    if Jogador.Collider:enter('Solido') then

    else
        local px, py = Jogador.Collider:getPosition()
        if Jogador.AtaqueCD == 0 then
            if love.keyboard.isDown("a","left") then
            
                if px - Jogador.Velocidade >= 0 then
                    Jogador.dirr = "Esquerda"
                    vectorX = -1
                end
            end
            if love.keyboard.isDown("d","right") then
            
                if px-16 + Jogador.Velocidade<= MapaX then
                    Jogador.dirr = "Direita"
                    vectorX = 1
                end 
            end

            if love.keyboard.isDown("w","up") then
                if py-8 - Jogador.Velocidade >= 0 then
                    Jogador.dirr = "Cima"
                    vectorY = -1
                end
            end

            if love.keyboard.isDown("s","down") then
                if py-44 + Jogador.Velocidade + Jogador.JogadorLargura*2<= MapaY then
                    Jogador.dirr = "Baixo"
                    vectorY = 1
                end
            end
        
            Jogador.Collider:setLinearVelocity(vectorX/Jogador.Velocidade, vectorY/Jogador.Velocidade )
            local px, py = Jogador.Collider:getPosition()
            Jogador.JogadorX = px
            Jogador.JogadorY = py
        end
    end
end

function setMap( mx,my)
    MapaX = mx
    MapaY = my
end

function getCollider(colider)
    Jogador.Collider = colider
end

function ataque()

    if love.keyboard.isDown("up") then

        if Jogador.AtaqueCD == 0 then

            tiros_pos = tiros_pos + 1
            tiros[tiros_pos] = {
                id = tiros_pos,
                tiro = initTiro(tiros_pos,"up")
            
            }
            Jogador.AtaqueCD = 50
        end 
   end

   if love.keyboard.isDown("down") then

        if Jogador.AtaqueCD == 0 then

            tiros_pos = tiros_pos + 1
            tiros[tiros_pos] = {
                id = tiros_pos,
                tiro = initTiro(tiros_pos,"down")
            
            }
            Jogador.AtaqueCD = 50
        end 
    end

    if love.keyboard.isDown("left") then

        if Jogador.AtaqueCD == 0 then

            tiros_pos = tiros_pos + 1
            tiros[tiros_pos] = {
                id = tiros_pos,
                tiro = initTiro(tiros_pos,"left")
            
            }
            Jogador.AtaqueCD = 50
        end 
    end

    if love.keyboard.isDown("right") then

        if Jogador.AtaqueCD == 0 then

            tiros_pos = tiros_pos + 1
            tiros[tiros_pos] = {
                id = tiros_pos,
                tiro = initTiro(tiros_pos,"right")
            
            }
            Jogador.AtaqueCD = 50
        end 
    end
end

function Tiro(id)

    local this = {}

    if(Jogador.dirr == "Cima")then
        this.vectX, this.vectY = 0, -1
    elseif(Jogador.dirr == "Baixo")then   
        this.vectX, this.vectY = 0, 1
    elseif(Jogador.dirr == "Esquerda")then
        this.vectX, this.vectY = -1,0
    elseif(Jogador.dirr == "Direita")then
        this.vectX, this.vectY = 1,0
    end

    local x, y = Jogador.Collider:getPosition()
    this.colider = world:newCircleCollider(x,y,3)
    this.colider:setCollisionClass('Ataque_Player')
    this.colider:setType('dynamic')

    this.id = id
    this.andar = true

    setmetatable(this, tirinho)
    return this

end


function cura()
    if Jogador.VidaAtual <= 30 then 
        if Jogador.Cura > 0 then
            Jogador.Cura = Jogador.Cura - 1
            vida = Jogador.VidaAtual + 20
            if Jogador.VidaAtual + vida > Jogador.VidaMax then
                Jogador.VidaAtual = 50
            else
                Jogador.VidaAtual = vida
            end
            
        end 
    end
    if cura_cool > 0 then
        cura_cool = cura_cool - 1
    end

    if cura_cool <= 0 then
        if Jogador.Cura < 2 then
            cura_cool = 1000
            Jogador.Cura = Jogador.Cura + 1
        end
    end
end

function getDamage(damage, type)

    local dano_verd = damage - Jogador.Defesa
    if dano_verd > 0 then
        Jogador.VidaAtual = Jogador.VidaAtual - dano_verd
    end
    if Jogador.VidaAtual <= 0 then
        rodando = false
    end
end

function getPosJogador()
    local px, py = Jogador.Collider:getPosition()
    return px, py
end

function setPosJogador(xx,yy)
    Jogador.JogadorX = xx
    Jogador.JogadorY = yy
end

function DestroyTiro(id)

    for i in ipairs(tiros) do
        if id == tiros[i].id then
            
            table.remove(tiros, i)                 
            
        end
    end
end

return Jogador