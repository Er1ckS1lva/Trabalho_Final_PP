
local tirinho = {}
tirinho.__index = tirinho

tirinho.img = love.graphics.newImage( "Sprite//Tiro.png" )


function initTiro(id,key)

    local this = {}

    if(key == "down")then
        this.vectX, this.vectY = 0, 1
    elseif(key == "up")then   
        this.vectX, this.vectY = 0, -1
    elseif(key == "left")then
        this.vectX, this.vectY = -1, 0
    elseif(key == "right")then
        this.vectX, this.vectY = 1, 0
    end

    local x, y = Jogador.Collider:getPosition()
    this.colider = world:newCircleCollider(x,y,3)
    this.colider:setCollisionClass('Ataque_Player')
    this.colider:setType('dynamic')
    this.id = id
    this.andar = true

    setmetatable(this, tirinho)
    return this
end

function tirinho:update()
    if self.andar then
        self:mov()
    end
end

function tirinho:draw()
    if self.andar then
        local px, py = self.colider:getPosition()
        love.graphics.draw( tirinho.img, px-3,py-3,0,3,3)
    end
end

function tirinho:mov()
  
    local px, py = self.colider:getPosition()
    

    XMAX, YMAX = getAreaMap(cenario)
   
    if px - 10 <= 0 then
        print("Errou")
        self.colider:destroy()
        self.andar = false
    elseif px  >= XMAX then
        print("Errou")
        self.colider:destroy()
        self.andar = false
    elseif py - 20  >= YMAX then
        print("Errou")
        self.colider:destroy()
        self.andar = false
    elseif py - 10 <= 0 then
        print("Errou")
        self.colider:destroy()
        self.andar = false
    elseif self.colider:enter('Inimigo') then
        
        print("Acerto Mizera")
        self.colider:destroy()
        self.andar = false
    elseif self.colider:enter('Solido') then
        self.andar = false
        print("Errou")
        --DestroyTiro(self.id)
        self.colider:destroy()
    elseif self.andar then
        self.colider:setLinearVelocity(self.vectX/30, self.vectY/30)
    end
end