
Os controles do jogo são : 

		AWSD -> movimento
		SETAS -> ataque nas direções



O objetivo é matar ou desviar dos inimigos por duas fases e encontrar a saida Final.



Os inimigos são gerados aleatoriamente e tem 4 possibilidades:

	Verde -> Fraco e Lento, da menos pontos
	Amarelo -> Um pouco mais forte e mais rapido, da um pouco a mais de pontos
	Azul -> Bem mais forte e rapido, da mais pontos
	Roxo -> Muito raro, muito forte e rapido, da muito ponto